

<?php $__env->startSection('title', 'Add Expense'); ?>

<?php $__env->startSection('page-title', 'Add Expense'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card form-card">
        <form action="<?php echo e(route('expenses.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="grid grid-2 gap-4">
                <label>Category<input type="text" name="category" value="<?php echo e(old('category')); ?>" /></label>
                <label>Amount<input type="number" name="amount" step="0.01" value="<?php echo e(old('amount', 0)); ?>" required /></label>
            </div>

            <div class="grid grid-2 gap-4">
                <label>Expense Date<input type="date" name="expense_date" value="<?php echo e(old('expense_date', date('Y-m-d'))); ?>" required /></label>
            </div>

            <label>Description<textarea name="description"><?php echo e(old('description')); ?></textarea></label>

            <button type="submit" class="button button-primary">Record Expense</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp1\htdocs\fees-manager\fees-manager-laravel\resources\views/expenses/create.blade.php ENDPATH**/ ?>