<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Role;
use App\Models\Employee;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class SubAdminController extends Controller
{
    // Only superadmin can manage sub-admins
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            if (session('user_role_slug') !== 'superadmin') {
                return redirect()->route('dashboard')->with('error', 'Unauthorized access.');
            }
            return $next($request);
        });
    }

    /**
     * Display all sub-admins and employees
     */
    public function index(Request $request)
    {
        $query = User::with('role', 'employee');

        if ($request->filled('search')) {
            $query->where('name', 'like', '%'.$request->search.'%')
                ->orWhere('email', 'like', '%'.$request->search.'%')
                ->orWhere('username', 'like', '%'.$request->search.'%');
        }

        if ($request->filled('role')) {
            $query->whereHas('role', function ($q) use ($request) {
                $q->where('slug', $request->role);
            });
        }

        $users = $query->where('id', '!=', session('user_id'))
            ->whereIn('role_id', function ($q) {
                $q->select('id')->from('roles')->whereIn('slug', ['admin', 'staff']);
            })
            ->latest()->paginate(12)->withQueryString();

        return view('sub_admins.index', compact('users'));
    }

    /**
     * Show form to create new sub-admin or employee
     */
    public function create()
    {
        $roles = Role::whereIn('slug', ['admin', 'staff'])->get();
        return view('sub_admins.create', compact('roles'));
    }

    /**
     * Store new sub-admin or employee
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:100'],
            'email' => ['required', 'email', 'unique:users,email'],
            'username' => ['required', 'string', 'max:50', 'unique:users,username'],
            'password' => ['required', 'string', 'min:6', 'confirmed'],
            'role' => ['required', 'in:admin,staff'],
            'status' => ['required', 'boolean'],
        ]);

        // Get role
        $role = Role::where('slug', $data['role'])->first();

        // Create user
        $user = User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'username' => $data['username'],
            'password' => Hash::make($data['password']),
            'role_id' => $role->id,
            'status' => $data['status'],
        ]);

        // If staff role, create employee record
        if ($data['role'] === 'staff') {
            Employee::create([
                'user_id' => $user->id,
                'employee_code' => 'EMP-'.$user->id,
                'designation' => 'Staff Member',
                'status' => $data['status'],
            ]);
        }

        return redirect()->route('sub-admins.index')->with('success', ucfirst($data['role']).' member created successfully.');
    }

    /**
     * Show edit form
     */
    public function edit(User $subAdmin)
    {
        $this->authorize('update', $subAdmin);
        $roles = Role::whereIn('slug', ['admin', 'staff'])->get();
        return view('sub_admins.edit', compact('subAdmin', 'roles'));
    }

    /**
     * Update sub-admin or employee
     */
    public function update(Request $request, User $subAdmin)
    {
        $this->authorize('update', $subAdmin);

        $data = $request->validate([
            'name' => ['required', 'string', 'max:100'],
            'email' => ['required', 'email', 'unique:users,email,'.$subAdmin->id],
            'username' => ['required', 'string', 'max:50', 'unique:users,username,'.$subAdmin->id],
            'password' => ['nullable', 'string', 'min:6', 'confirmed'],
            'status' => ['required', 'boolean'],
        ]);

        $updateData = [
            'name' => $data['name'],
            'email' => $data['email'],
            'username' => $data['username'],
            'status' => $data['status'],
        ];

        if ($data['password']) {
            $updateData['password'] = Hash::make($data['password']);
        }

        $subAdmin->update($updateData);

        // Update employee status if staff
        if ($subAdmin->role?->slug === 'staff' && $subAdmin->employee) {
            $subAdmin->employee->update(['status' => $data['status']]);
        }

        return redirect()->route('sub-admins.index')->with('success', 'User updated successfully.');
    }

    /**
     * Delete sub-admin or employee
     */
    public function destroy(User $subAdmin)
    {
        $this->authorize('delete', $subAdmin);

        $name = $subAdmin->name;
        
        // Delete associated employee record if exists
        if ($subAdmin->employee) {
            $subAdmin->employee->delete();
        }

        $subAdmin->delete();

        return redirect()->route('sub-admins.index')->with('success', "User '$name' deleted successfully.");
    }
}
