

<?php $__env->startSection('title', 'Students'); ?>

<?php $__env->startSection('page-title', 'Student Management'); ?>

<?php $__env->startSection('content'); ?>
    <div class="toolbar">
        <form class="filter-form" method="GET" action="<?php echo e(route('students.index')); ?>">
            <input type="text" name="search" placeholder="Search students" value="<?php echo e(request('search')); ?>" />
            <select name="course_id">
                <option value="">All courses</option>
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($course->id); ?>" <?php echo e((string) request('course_id') === (string) $course->id ? 'selected' : ''); ?>>
                        <?php echo e($course->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <select name="course_duration">
                <option value="">All durations</option>
                <?php $__currentLoopData = $durations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $duration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($duration); ?>" <?php echo e(request('course_duration') === $duration ? 'selected' : ''); ?>><?php echo e($duration); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <select name="status">
                <option value="">All status</option>
                <option value="active" <?php echo e(request('status') === 'active' ? 'selected' : ''); ?>>Active</option>
                <option value="inactive" <?php echo e(request('status') === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
            </select>
            <button type="submit" class="button button-secondary">Filter</button>
        </form>
        <a href="<?php echo e(route('students.create')); ?>" class="button button-primary">Add Student</a>
    </div>

    <div>
        <div class="student-card-grid">
            <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="student-card">
                    <div class="student-card-top">
                        <div class="student-avatar"><?php echo e(strtoupper(substr($student->first_name, 0, 1))); ?></div>
                        <div>
                            <h3><?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?></h3>
                            <p><?php echo e($student->admission_no); ?><?php echo e($student->roll_no ? ' / '.$student->roll_no : ''); ?></p>
                        </div>
                        <span class="status-pill <?php echo e($student->status ? 'active' : 'inactive'); ?>"><?php echo e($student->status ? 'Active' : 'Inactive'); ?></span>
                    </div>

                    <dl class="student-card-details">
                        <div>
                            <dt>Course</dt>
                            <dd><?php echo e(optional($student->course)->name ?? $student->class ?? 'Not assigned'); ?></dd>
                        </div>
                        <div>
                            <dt>Type</dt>
                            <dd>
                                <?php if(($student->student_type ?? 'Regular (On Campus)') === 'Online'): ?>
                                    <span class="badge bg-info-light text-info px-2 py-1" style="background-color: rgba(23, 162, 184, 0.1); font-size: 0.75rem; font-weight: 600; border-radius: 4px;">Online</span>
                                <?php elseif(($student->student_type ?? 'Regular (On Campus)') === 'Regular (Internship)'): ?>
                                    <span class="badge bg-purple-light text-purple px-2 py-1" style="background-color: rgba(111, 66, 193, 0.1); color: #6f42c1 !important; font-size: 0.75rem; font-weight: 600; border-radius: 4px;">Regular (Internship)</span>
                                <?php else: ?>
                                    <span class="badge bg-warning-light text-warning px-2 py-1" style="background-color: rgba(255, 85, 50, 0.1); color: var(--first-color) !important; font-size: 0.75rem; font-weight: 600; border-radius: 4px;">Regular (On Campus)</span>
                                <?php endif; ?>
                            </dd>
                        </div>
                        <div>
                            <dt>Duration</dt>
                            <dd><?php echo e($student->course_duration ?? $student->section ?? 'Not set'); ?></dd>
                        </div>
                        <div>
                            <dt>Phone</dt>
                            <dd><?php echo e($student->phone ?? 'Not added'); ?></dd>
                        </div>
                        <div>
                            <dt>Aadhar No</dt>
                            <dd><?php echo e($student->aadhar_number ? implode(' ', str_split($student->aadhar_number, 4)) : 'Not added'); ?></dd>
                        </div>
                        <div>
                            <dt>Admission Date</dt>
                            <dd><?php echo e($student->admission_date ?? 'Not added'); ?></dd>
                        </div>
                    </dl>

                    <div class="student-card-actions">
                        <a href="<?php echo e(route('students.edit', $student)); ?>" class="button button-secondary small">Edit</a>
                        <form action="<?php echo e(route('students.destroy', $student)); ?>" method="POST" class="inline-form" onsubmit="return confirm('Delete student?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="button button-danger small">Delete</button>
                        </form>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="card">No students found.</div>
            <?php endif; ?>
        </div>
        <div class="pagination-wrapper"><?php echo e($students->links()); ?></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp1\htdocs\fees-manager\fees-manager-laravel\resources\views/students/index.blade.php ENDPATH**/ ?>