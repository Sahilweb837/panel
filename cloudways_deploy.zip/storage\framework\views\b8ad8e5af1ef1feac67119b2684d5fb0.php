<?php $__env->startSection('title', 'Add Course'); ?>

<?php $__env->startSection('page-title', 'Add Course'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card form-card">
        <form action="<?php echo e(route('courses.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="grid grid-2 gap-4">
                <label>Course Name<input type="text" name="name" value="<?php echo e(old('name')); ?>" required /></label>
                <label>Course Code<input type="text" name="code" value="<?php echo e(old('code')); ?>" /></label>
            </div>

            <div class="grid grid-2 gap-4">
                <label>Duration
                    <select name="duration">
                        <option value="">Flexible</option>
                        <option value="45 Days" <?php echo e(old('duration') === '45 Days' ? 'selected' : ''); ?>>45 Days</option>
                        <option value="1 Month" <?php echo e(old('duration') === '1 Month' ? 'selected' : ''); ?>>1 Month</option>
                        <option value="6 Months" <?php echo e(old('duration') === '6 Months' ? 'selected' : ''); ?>>6 Months</option>
                        <option value="1 Year" <?php echo e(old('duration') === '1 Year' ? 'selected' : ''); ?>>1 Year</option>
                    </select>
                </label>
                <label>Course Fee<input type="number" name="fee" min="0" step="0.01" value="<?php echo e(old('fee', 0)); ?>" /></label>
            </div>

            <label class="checkbox-input">
                <input type="checkbox" name="status" value="1" <?php echo e(old('status', true) ? 'checked' : ''); ?> /> Active
            </label>

            <button type="submit" class="button button-primary">Create Course</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp1\htdocs\fees-manager\fees-manager-laravel\resources\views/courses/create.blade.php ENDPATH**/ ?>