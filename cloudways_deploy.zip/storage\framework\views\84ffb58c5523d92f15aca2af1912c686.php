

<?php $__env->startSection('title', 'Attendance'); ?>

<?php $__env->startSection('page-title', 'Attendance Management'); ?>

<?php $__env->startSection('content'); ?>
    <div class="toolbar">
        <form class="filter-form" method="GET" action="<?php echo e(route('attendances.index')); ?>">
            <input type="text" name="student" placeholder="Student search" value="<?php echo e(request('student')); ?>" />
            <input type="date" name="date" value="<?php echo e(request('date')); ?>" />
            <button type="submit" class="button button-secondary">Filter</button>
        </form>
        <a href="<?php echo e(route('attendances.create')); ?>" class="button button-primary">Record Attendance</a>
    </div>

    <div class="card table-card">
        <table class="table">
            <thead>
                <tr>
                    <th>Student</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Fine</th>
                    <th>Remarks</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($attendance->student->first_name); ?> <?php echo e($attendance->student->last_name); ?></td>
                        <td><?php echo e($attendance->attendance_date); ?></td>
                        <td><?php echo e($attendance->status); ?></td>
                        <td><?php echo e(number_format($attendance->fine, 2)); ?></td>
                        <td><?php echo e($attendance->remarks); ?></td>
                        <td class="action-cell">
                            <form action="<?php echo e(route('attendances.destroy', $attendance)); ?>" method="POST" class="inline-form" onsubmit="return confirm('Delete attendance record?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="button button-danger small">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6">No attendance records found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="pagination-wrapper"><?php echo e($attendances->links()); ?></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp1\htdocs\fees-manager\fees-manager-laravel\resources\views/attendances/index.blade.php ENDPATH**/ ?>