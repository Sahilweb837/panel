<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title><?php echo $__env->yieldContent('title', 'Fees Manager'); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
</head>
<body class="app-shell">
    <!-- Sidebar Overlay Backdrop for Mobile -->
    <div class="sidebar-overlay" id="sidebar-overlay"></div>

    <!-- Mobile Top Navigation Bar -->
    <header class="mobile-navbar d-lg-none d-flex align-items-center justify-content-between p-3 border-bottom">
        <div class="d-flex align-items-center gap-2">
            <button type="button" class="btn btn-link p-0 me-2" id="sidebar-toggle-btn">
                <i class="fas fa-bars fa-lg"></i>
            </button>
            <div class="brand-mark-sm">
                <img src="<?php echo e(asset('image.png')); ?>" alt="Netcoder Fees" class="brand-logo-sm">
            </div>
            <div>
                <h1 class="brand-title-sm mb-0">Netcoder Fees</h1>
            </div>
        </div>
        <button type="button" class="eye-protection-btn theme-toggle me-2 px-3 py-1" style="height: auto; border-radius: 20px; font-size: 0.8rem;" data-theme-toggle title="Toggle Eye Protection Theme">
            <span class="eye-icon-wrapper" style="width: 14px; height: 14px; font-size: 0.8rem;"><i class="fas fa-eye-slash"></i></span>
            <span class="btn-text d-none d-sm-inline">Eye Protection</span>
        </button>
    </header>

    <aside class="sidebar">
        <!-- Close button for Mobile sidebar -->
        <button type="button" class="btn-close-custom d-lg-none" id="sidebar-close-btn" aria-label="Close">
            <i class="fas fa-times"></i>
        </button>
        <div class="brand">
            <div class="brand-mark">
                <img src="<?php echo e(asset('image.png')); ?>" alt="Netcoder Fees" class="brand-logo">
            </div>
            <div>
                <h1>Netcoder Fees</h1>
                <p>Institute ERP</p>
            </div>
        </div>

        <nav class="nav-menu">
            <a href="<?php echo e(route('dashboard')); ?>" class="nav-link<?php echo e(request()->routeIs('dashboard') ? ' active' : ''); ?>">
                <i class="fas fa-chart-line"></i>
                <span>Dashboard</span>
            </a>
            <?php if(($currentUser->role?->slug ?? null) !== 'staff'): ?>
                <?php if(($currentUser->role?->slug ?? null) === 'superadmin'): ?>
                    <a href="<?php echo e(route('sub-admins.index')); ?>" class="nav-link<?php echo e(request()->routeIs('sub-admins.*') ? ' active' : ''); ?>">
                        <i class="fas fa-user-shield"></i>
                        <span>Sub-Admins & Staff</span>
                    </a>
                <?php endif; ?>
                <a href="<?php echo e(route('courses.index')); ?>" class="nav-link<?php echo e(request()->routeIs('courses.*') ? ' active' : ''); ?>">
                    <i class="fas fa-book"></i>
                    <span>Courses</span>
                </a>
                <a href="<?php echo e(route('students.index')); ?>" class="nav-link<?php echo e(request()->routeIs('students.*') ? ' active' : ''); ?>">
                    <i class="fas fa-users"></i>
                    <span>Students</span>
                </a>
                <a href="<?php echo e(route('employees.index')); ?>" class="nav-link<?php echo e(request()->routeIs('employees.*') ? ' active' : ''); ?>">
                    <i class="fas fa-person-chalkboard"></i>
                    <span>Staff</span>
                </a>
                <a href="<?php echo e(route('employee-attendances.index')); ?>" class="nav-link<?php echo e(request()->routeIs('employee-attendances.*') ? ' active' : ''); ?>">
                    <i class="fas fa-clipboard-user"></i>
                    <span>Staff Attendance</span>
                </a>
                <a href="<?php echo e(route('attendances.index')); ?>" class="nav-link<?php echo e(request()->routeIs('attendances.*') ? ' active' : ''); ?>">
                    <i class="fas fa-clipboard-check"></i>
                    <span>Student Attendance</span>
                </a>
                <a href="<?php echo e(route('fee_invoices.index')); ?>" class="nav-link<?php echo e(request()->routeIs('fee_invoices.*') ? ' active' : ''); ?>">
                    <i class="fas fa-file-invoice-dollar"></i>
                    <span>Fee Invoices</span>
                </a>
                <a href="<?php echo e(route('expenses.index')); ?>" class="nav-link<?php echo e(request()->routeIs('expenses.*') ? ' active' : ''); ?>">
                    <i class="fas fa-money-bill-wave"></i>
                    <span>Expenses</span>
                </a>
                <a href="<?php echo e(route('salary_slips.index')); ?>" class="nav-link<?php echo e(request()->routeIs('salary_slips.*') ? ' active' : ''); ?>">
                    <i class="fas fa-wallet"></i>
                    <span>Salary Slips</span>
                </a>
            <?php endif; ?>
        </nav>

        <div class="sidebar-footer">
            <p>Logged in as</p>
            <strong><?php echo e(session('user_name', 'Guest')); ?></strong>
            <form action="<?php echo e(route('logout')); ?>" method="POST" class="logout-form">
                <?php echo csrf_field(); ?>
                <button type="submit" class="button button-secondary">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </button>
            </form>
        </div>
    </aside>

    <main class="main-content">
        <header class="topbar">
            <div>
                <h2><?php echo $__env->yieldContent('page-title', 'Management'); ?></h2>
                <p class="page-subtitle">Manage courses, students, fees, attendance, salaries and expenses.</p>
            </div>
            <button type="button" class="eye-protection-btn" data-theme-toggle title="Toggle Eye Protection Theme">
                <span class="eye-icon-wrapper"><i class="fas fa-eye-slash"></i></span>
                <span class="btn-text">Eye Protection</span>
            </button>
        </header>

        <section class="page-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <div><?php echo e(session('success')); ?></div>
                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>
        </section>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const sidebar = document.querySelector('.sidebar');
            const toggleBtn = document.getElementById('sidebar-toggle-btn');
            const closeBtn = document.getElementById('sidebar-close-btn');
            const overlay = document.getElementById('sidebar-overlay');

            const toggleSidebar = () => {
                sidebar.classList.toggle('show');
                overlay.classList.toggle('show');
                document.body.classList.toggle('sidebar-open');
            };

            if (toggleBtn) toggleBtn.addEventListener('click', toggleSidebar);
            if (closeBtn) closeBtn.addEventListener('click', toggleSidebar);
            if (overlay) overlay.addEventListener('click', toggleSidebar);
        });
    </script>
</body>
</html>
<?php /**PATH D:\xammp1\htdocs\fees-manager\fees-manager-laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>