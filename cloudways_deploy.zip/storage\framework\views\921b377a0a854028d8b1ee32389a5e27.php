

<?php $__env->startSection('title', 'Add Staff'); ?>

<?php $__env->startSection('page-title', 'Add Staff'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card form-card">
        <form action="<?php echo e(route('employees.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="grid grid-2 gap-4">
                <label>Employee Code<input type="text" name="employee_code" value="<?php echo e(old('employee_code')); ?>" required /></label>
                <label>Staff Name<input type="text" name="staff_name" value="<?php echo e(old('staff_name')); ?>" /></label>
            </div>

            <div class="grid grid-2 gap-4">
                <label>Login Email<input type="email" name="login_email" value="<?php echo e(old('login_email')); ?>" /></label>
                <label>Login Username<input type="text" name="login_username" value="<?php echo e(old('login_username')); ?>" /></label>
            </div>

            <div class="grid grid-2 gap-4">
                <label>Login Password<input type="password" name="login_password" /></label>
                <label>Phone<input type="text" name="phone" value="<?php echo e(old('phone')); ?>" /></label>
            </div>

            <div class="grid grid-2 gap-4">
                <label>Department<input type="text" name="department" value="<?php echo e(old('department')); ?>" /></label>
                <label>Designation<input type="text" name="designation" value="<?php echo e(old('designation')); ?>" /></label>
            </div>

            <div class="grid grid-2 gap-4">
                <label>Salary<input type="number" name="salary" step="0.01" value="<?php echo e(old('salary', 0)); ?>" required /></label>
                <label>Joining Date<input type="date" name="joining_date" value="<?php echo e(old('joining_date')); ?>" /></label>
            </div>

            <label>Address<textarea name="address"><?php echo e(old('address')); ?></textarea></label>

            <label class="checkbox-input">
                <input type="checkbox" name="status" value="1" <?php echo e(old('status', true) ? 'checked' : ''); ?> /> Active
            </label>

            <button type="submit" class="button button-primary">Create Staff</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp1\htdocs\fees-manager\fees-manager-laravel\resources\views/employees/create.blade.php ENDPATH**/ ?>