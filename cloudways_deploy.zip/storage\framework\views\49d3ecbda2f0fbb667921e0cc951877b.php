

<?php $__env->startSection('title', 'Salary Slips'); ?>

<?php $__env->startSection('page-title', 'Salary Slip Management'); ?>

<?php $__env->startSection('content'); ?>
    <div class="toolbar">
        <a href="<?php echo e(route('salary_slips.create')); ?>" class="button button-primary">Generate Salary Slip</a>
    </div>

    <div class="card table-card">
        <table class="table">
            <thead>
                <tr>
                    <th>Employee</th>
                    <th>Month</th>
                    <th>Net Pay</th>
                    <th>Status</th>
                    <th>Payment Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $salarySlips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($slip->employee->employee_code); ?></td>
                        <td><?php echo e($slip->month); ?> <?php echo e($slip->year); ?></td>
                        <td><?php echo e(number_format($slip->net_pay, 2)); ?></td>
                        <td><?php echo e($slip->status); ?></td>
                        <td><?php echo e($slip->payment_date ?? 'Not paid'); ?></td>
                        <td class="action-cell">
                            <form action="<?php echo e(route('salary_slips.destroy', $slip)); ?>" method="POST" class="inline-form" onsubmit="return confirm('Delete salary slip?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="button button-danger small">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6">No salary slips generated.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="pagination-wrapper"><?php echo e($salarySlips->links()); ?></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp1\htdocs\fees-manager\fees-manager-laravel\resources\views/salary_slips/index.blade.php ENDPATH**/ ?>