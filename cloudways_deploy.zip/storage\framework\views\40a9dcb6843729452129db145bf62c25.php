<?php $__env->startSection('title', 'Courses'); ?>

<?php $__env->startSection('page-title', 'Course Management'); ?>

<?php $__env->startSection('content'); ?>
    <div class="toolbar">
        <form class="filter-form" method="GET" action="<?php echo e(route('courses.index')); ?>">
            <input type="text" name="search" placeholder="Search courses" value="<?php echo e(request('search')); ?>" />
            <button type="submit" class="button button-secondary">Filter</button>
        </form>
        <a href="<?php echo e(route('courses.create')); ?>" class="button button-primary">Add Course</a>
    </div>

    <div class="course-card-grid">
        <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="course-card">
                <div>
                    <p class="course-code"><?php echo e($course->code ?? 'COURSE'); ?></p>
                    <h3><?php echo e($course->name); ?></h3>
                    <p><?php echo e($course->duration ?? 'Flexible duration'); ?></p>
                </div>
                <dl>
                    <div>
                        <dt>Fee</dt>
                        <dd>Rs. <?php echo e(number_format($course->fee, 2)); ?></dd>
                    </div>
                    <div>
                        <dt>Students</dt>
                        <dd><?php echo e($course->students_count); ?></dd>
                    </div>
                    <div>
                        <dt>Status</dt>
                        <dd><?php echo e($course->status ? 'Active' : 'Inactive'); ?></dd>
                    </div>
                </dl>
                <form action="<?php echo e(route('courses.destroy', $course)); ?>" method="POST" onsubmit="return confirm('Delete course? Existing students will keep their records.');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="button button-danger small">Delete</button>
                </form>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="card">No courses found. Create a course first, then assign it to student cards.</div>
        <?php endif; ?>
    </div>

    <div class="pagination-wrapper"><?php echo e($courses->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp1\htdocs\fees-manager\fees-manager-laravel\resources\views/courses/index.blade.php ENDPATH**/ ?>