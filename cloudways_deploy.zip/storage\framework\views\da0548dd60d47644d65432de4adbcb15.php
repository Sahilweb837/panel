

<?php $__env->startSection('title', 'Record Attendance'); ?>

<?php $__env->startSection('page-title', 'Record Attendance'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card form-card">
        <form action="<?php echo e(route('attendances.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="grid grid-2 gap-4">
                <label>Student
                    <select name="student_id" required>
                        <option value="">Choose a student</option>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($student->id); ?>" <?php echo e(old('student_id') == $student->id ? 'selected' : ''); ?>>
                                <?php echo e($student->admission_no); ?> - <?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
                <label>Date<input type="date" name="attendance_date" value="<?php echo e(old('attendance_date', date('Y-m-d'))); ?>" required /></label>
            </div>

            <div class="grid grid-2 gap-4">
                <label>Status
                    <select name="status" required>
                        <option value="Present" <?php echo e(old('status') === 'Present' ? 'selected' : ''); ?>>Present</option>
                        <option value="Absent" <?php echo e(old('status') === 'Absent' ? 'selected' : ''); ?>>Absent</option>
                        <option value="Late" <?php echo e(old('status') === 'Late' ? 'selected' : ''); ?>>Late</option>
                        <option value="Leave" <?php echo e(old('status') === 'Leave' ? 'selected' : ''); ?>>Leave</option>
                    </select>
                </label>
                <label>Fine Amount<input type="number" name="fine" step="0.01" value="<?php echo e(old('fine', 0)); ?>" /></label>
            </div>

            <label>Remarks<textarea name="remarks"><?php echo e(old('remarks')); ?></textarea></label>

            <button type="submit" class="button button-primary">Save Attendance</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp1\htdocs\fees-manager\fees-manager-laravel\resources\views/attendances/create.blade.php ENDPATH**/ ?>