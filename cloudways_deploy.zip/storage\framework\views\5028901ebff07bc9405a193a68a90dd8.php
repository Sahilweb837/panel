

<?php $__env->startSection('title', 'Generate Salary Slip'); ?>
<?php $__env->startSection('page-title', 'Generate Salary Slip'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card" style="max-width: 700px;">
        <form action="<?php echo e(route('salary_slips.store')); ?>" method="POST" class="form-card">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="employee_id">
                    <i class="fas fa-person-chalkboard"></i> Employee
                </label>
                <select id="employee_id" name="employee_id" required class="form-input <?php echo e($errors->has('employee_id') ? 'is-invalid' : ''); ?>">
                    <option value="">-- Select an employee --</option>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($employee->id); ?>" <?php echo e(old('employee_id') == $employee->id ? 'selected' : ''); ?>>
                            <?php echo e($employee->employee_code); ?> - <?php echo e($employee->user?->name); ?> (<?php echo e($employee->designation); ?>)
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['employee_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small style="color: var(--danger-text);"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="grid grid-2 gap-4">
                <div class="form-group">
                    <label for="month">
                        <i class="fas fa-calendar-alt"></i> Month
                    </label>
                    <input type="text" id="month" name="month" value="<?php echo e(old('month')); ?>" placeholder="e.g., January, March" required class="form-input <?php echo e($errors->has('month') ? 'is-invalid' : ''); ?>" />
                    <?php $__errorArgs = ['month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small style="color: var(--danger-text);"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="year">
                        <i class="fas fa-calendar-check"></i> Year
                    </label>
                    <input type="text" id="year" name="year" value="<?php echo e(old('year', now()->year)); ?>" required class="form-input <?php echo e($errors->has('year') ? 'is-invalid' : ''); ?>" />
                    <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small style="color: var(--danger-text);"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="grid grid-2 gap-4">
                <div class="form-group">
                    <label for="basic_salary">
                        <i class="fas fa-money-bill"></i> Basic Salary
                    </label>
                    <input type="number" id="basic_salary" name="basic_salary" step="0.01" value="<?php echo e(old('basic_salary', 0)); ?>" required placeholder="0.00" class="form-input <?php echo e($errors->has('basic_salary') ? 'is-invalid' : ''); ?>" />
                    <?php $__errorArgs = ['basic_salary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small style="color: var(--danger-text);"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="allowances">
                        <i class="fas fa-plus-circle"></i> Allowances
                    </label>
                    <input type="number" id="allowances" name="allowances" step="0.01" value="<?php echo e(old('allowances', 0)); ?>" placeholder="0.00" class="form-input" />
                </div>
            </div>

            <div class="grid grid-2 gap-4">
                <div class="form-group">
                    <label for="deductions">
                        <i class="fas fa-minus-circle"></i> Deductions
                    </label>
                    <input type="number" id="deductions" name="deductions" step="0.01" value="<?php echo e(old('deductions', 0)); ?>" placeholder="0.00" class="form-input" />
                </div>
                <div class="form-group">
                    <label for="payment_date">
                        <i class="fas fa-calendar"></i> Payment Date (Optional)
                    </label>
                    <input type="date" id="payment_date" name="payment_date" value="<?php echo e(old('payment_date', date('Y-m-d'))); ?>" class="form-input" />
                </div>
            </div>

            <div class="form-group">
                <label for="status">
                    <i class="fas fa-info-circle"></i> Status
                </label>
                <select id="status" name="status" required class="form-input <?php echo e($errors->has('status') ? 'is-invalid' : ''); ?>">
                    <option value="">-- Select Status --</option>
                    <option value="Pending" <?php echo e(old('status') === 'Pending' ? 'selected' : ''); ?>>⏳ Pending</option>
                    <option value="Paid" <?php echo e(old('status') === 'Paid' ? 'selected' : ''); ?>>✓ Paid</option>
                </select>
                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small style="color: var(--danger-text);"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div style="background: var(--surface-soft); padding: 16px; border-radius: 8px; margin-top: 20px; margin-bottom: 20px;">
                <h4 style="margin-top: 0;">Net Salary Calculation</h4>
                <div class="grid grid-2" style="gap: 16px;">
                    <div>
                        <p style="margin: 0 0 4px; color: var(--muted); font-size: 0.9rem;">Basic Salary</p>
                        <p style="margin: 0; font-weight: bold; font-size: 1.1rem;" id="calc-basic">0.00</p>
                    </div>
                    <div>
                        <p style="margin: 0 0 4px; color: var(--muted); font-size: 0.9rem;">+ Allowances</p>
                        <p style="margin: 0; font-weight: bold; font-size: 1.1rem;" id="calc-allowance">0.00</p>
                    </div>
                    <div>
                        <p style="margin: 0 0 4px; color: var(--muted); font-size: 0.9rem;">- Deductions</p>
                        <p style="margin: 0; font-weight: bold; font-size: 1.1rem;" id="calc-deduction">0.00</p>
                    </div>
                    <div>
                        <p style="margin: 0 0 4px; color: var(--first-color); font-size: 0.9rem; font-weight: 600;">Net Salary</p>
                        <p style="margin: 0; font-weight: bold; font-size: 1.3rem; color: var(--first-color);" id="calc-net">0.00</p>
                    </div>
                </div>
            </div>

            <div style="display: flex; gap: 12px;">
                <button type="submit" class="button button-primary" style="flex: 1;">
                    <i class="fas fa-file-alt"></i> Generate Salary Slip
                </button>
                <a href="<?php echo e(route('salary_slips.index')); ?>" class="button button-secondary" style="flex: 1; text-align: center;">
                    <i class="fas fa-times"></i> Cancel
                </a>
            </div>
        </form>
    </div>

    <script>
        function updateCalculation() {
            const basic = parseFloat(document.getElementById('basic_salary').value) || 0;
            const allowance = parseFloat(document.getElementById('allowances').value) || 0;
            const deduction = parseFloat(document.getElementById('deductions').value) || 0;
            const net = basic + allowance - deduction;

            document.getElementById('calc-basic').textContent = basic.toFixed(2);
            document.getElementById('calc-allowance').textContent = allowance.toFixed(2);
            document.getElementById('calc-deduction').textContent = deduction.toFixed(2);
            document.getElementById('calc-net').textContent = net.toFixed(2);
        }

        document.getElementById('basic_salary').addEventListener('input', updateCalculation);
        document.getElementById('allowances').addEventListener('input', updateCalculation);
        document.getElementById('deductions').addEventListener('input', updateCalculation);

        updateCalculation();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp1\htdocs\fees-manager\fees-manager-laravel\resources\views/salary_slips/create.blade.php ENDPATH**/ ?>