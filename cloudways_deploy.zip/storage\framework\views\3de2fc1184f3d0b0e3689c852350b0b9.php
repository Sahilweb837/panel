<?php $__env->startSection('title', 'Record Staff Attendance'); ?>

<?php $__env->startSection('page-title', 'Record Daily Staff Attendance'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mb-4">
        <div class="col-12">
            <div class="card p-4 border-0 shadow-sm">
                <form method="GET" action="<?php echo e(route('employee-attendances.create')); ?>" id="date-select-form" class="d-flex align-items-end justify-content-between flex-wrap gap-3">
                    <div style="flex: 1; min-width: 250px;">
                        <label for="date-picker" class="form-label text-muted uppercase-bold mb-2">Select Attendance Date</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light border-end-0"><i class="fas fa-calendar-alt text-first"></i></span>
                            <input type="date" id="date-picker" name="date" class="form-control border-start-0" value="<?php echo e($date); ?>" max="<?php echo e(date('Y-m-d')); ?>" onchange="document.getElementById('date-select-form').submit();" style="border-radius: 0 8px 8px 0; padding: 10px 14px;" />
                        </div>
                        <small class="text-muted d-block mt-2">Changing the date will automatically load any previously recorded attendance for that day.</small>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="button" onclick="markAll('Present')" class="button btn-light px-3"><i class="fas fa-check-double me-2"></i>Mark All Present</button>
                        <button type="button" onclick="markAll('Absent')" class="button button-danger small px-3" style="background-color: rgba(220, 53, 69, 0.1); color: #dc3545; border: 1px solid rgba(220, 53, 69, 0.2);"><i class="fas fa-times-circle me-2"></i>Mark All Absent</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php if($employees->isEmpty()): ?>
        <div class="card text-center py-5">
            <i class="fas fa-users-slash fa-3x mb-3 text-light"></i>
            <h4>No Employees Found</h4>
            <p class="text-muted">Please add active staff members first under the Staff Management section.</p>
            <a href="<?php echo e(route('employees.create')); ?>" class="button button-primary mt-2">Add Staff Member</a>
        </div>
    <?php else: ?>
        <div class="card table-card border-0 shadow-sm">
            <form action="<?php echo e(route('employee-attendances.store')); ?>" method="POST" id="attendance-log-form">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="attendance_date" value="<?php echo e($date); ?>" />

                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light-head">
                            <tr>
                                <th class="ps-4" style="width: 30%;">Staff Member</th>
                                <th style="width: 15%;">Code</th>
                                <th style="width: 30%;" class="text-center">Attendance Status</th>
                                <th class="pe-4" style="width: 25%;">Remarks</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $existing = $existingAttendances->get($employee->id);
                                    $status = $existing ? $existing->status : 'Present';
                                    $remarks = $existing ? $existing->remarks : '';
                                ?>
                                <tr>
                                    <td class="ps-4">
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-circle-sm bg-light-orange text-first me-3" style="width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; background-color: var(--first-color-light);">
                                                <?php echo e(strtoupper(substr($employee->user->name ?? 'S', 0, 2))); ?>

                                            </div>
                                            <div>
                                                <h6 class="mb-0 text-dark-title"><?php echo e($employee->user->name ?? 'N/A'); ?></h6>
                                                <small class="text-muted"><?php echo e($employee->department ?? 'General'); ?> &bull; <?php echo e($employee->designation ?? 'Staff'); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark border"><?php echo e($employee->employee_code); ?></span>
                                    </td>
                                    <td class="text-center">
                                        <div class="d-inline-flex gap-2" role="group" aria-label="Attendance Status Toggle">
                                            <!-- Present -->
                                            <input type="radio" class="btn-check" name="attendance[<?php echo e($employee->id); ?>][status]" id="status_<?php echo e($employee->id); ?>_present" value="Present" <?php echo e($status === 'Present' ? 'checked' : ''); ?> autocomplete="off" />
                                            <label class="btn btn-outline-success btn-sm px-3 rounded-pill" style="font-size: 0.8rem; font-weight: 600;" for="status_<?php echo e($employee->id); ?>_present">Present</label>

                                            <!-- Late -->
                                            <input type="radio" class="btn-check" name="attendance[<?php echo e($employee->id); ?>][status]" id="status_<?php echo e($employee->id); ?>_late" value="Late" <?php echo e($status === 'Late' ? 'checked' : ''); ?> autocomplete="off" />
                                            <label class="btn btn-outline-warning btn-sm px-3 rounded-pill" style="font-size: 0.8rem; font-weight: 600;" for="status_<?php echo e($employee->id); ?>_late">Late</label>

                                            <!-- Absent -->
                                            <input type="radio" class="btn-check" name="attendance[<?php echo e($employee->id); ?>][status]" id="status_<?php echo e($employee->id); ?>_absent" value="Absent" <?php echo e($status === 'Absent' ? 'checked' : ''); ?> autocomplete="off" />
                                            <label class="btn btn-outline-danger btn-sm px-3 rounded-pill" style="font-size: 0.8rem; font-weight: 600;" for="status_<?php echo e($employee->id); ?>_absent">Absent</label>

                                            <!-- Leave -->
                                            <input type="radio" class="btn-check" name="attendance[<?php echo e($employee->id); ?>][status]" id="status_<?php echo e($employee->id); ?>_leave" value="Leave" <?php echo e($status === 'Leave' ? 'checked' : ''); ?> autocomplete="off" />
                                            <label class="btn btn-outline-info btn-sm px-3 rounded-pill" style="font-size: 0.8rem; font-weight: 600;" for="status_<?php echo e($employee->id); ?>_leave">Leave</label>
                                        </div>
                                    </td>
                                    <td class="pe-4">
                                        <input type="text" name="attendance[<?php echo e($employee->id); ?>][remarks]" class="form-control" placeholder="Add optional remarks..." value="<?php echo e($remarks); ?>" style="padding: 6px 12px; font-size: 0.85rem; border-radius: 6px;" />
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="card-footer p-4 border-top bg-light d-flex align-items-center justify-content-between flex-wrap gap-3">
                    <div class="text-muted">
                        <i class="fas fa-info-circle me-1 text-first"></i>
                        <span>Clicking save will write/update records for <strong><?php echo e(\Carbon\Carbon::parse($date)->format('M d, Y')); ?></strong>.</span>
                    </div>
                    <div class="d-flex gap-2">
                        <a href="<?php echo e(route('employee-attendances.index')); ?>" class="button btn-light px-4">Cancel</a>
                        <button type="submit" class="button button-primary px-5"><i class="fas fa-save me-2"></i>Save Daily Attendance</button>
                    </div>
                </div>
            </form>
        </div>
    <?php endif; ?>

    <script>
        function markAll(status) {
            const checks = document.querySelectorAll(`input[type="radio"][value="${status}"]`);
            checks.forEach(radio => {
                radio.checked = true;
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp1\htdocs\fees-manager\fees-manager-laravel\resources\views/employee_attendances/create.blade.php ENDPATH**/ ?>