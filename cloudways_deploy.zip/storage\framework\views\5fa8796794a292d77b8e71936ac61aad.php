

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Stat Cards Deck -->
    <div class="row g-4 mb-4">
        <!-- Students Stat -->
        <div class="col-12 col-sm-6 col-xl-3">
            <div class="card stat-card border-0 shadow-sm h-100 position-relative overflow-hidden">
                <div class="card-body p-4">
                    <div class="stat-icon-wrapper d-flex align-items-center justify-content-center bg-light-orange text-first rounded-3 mb-3">
                        <i class="fas fa-users fa-lg"></i>
                    </div>
                    <span class="text-muted small-text uppercase-bold d-block mb-1">Students Registered</span>
                    <h3 class="display-6 fw-bold mb-0 text-dark-title"><?php echo e($studentCount); ?></h3>
                    <div class="stat-trend mt-2 text-success small d-flex align-items-center gap-1">
                        <i class="fas fa-arrow-trend-up"></i>
                        <span>Active Enrolled</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Staff Stat -->
        <div class="col-12 col-sm-6 col-xl-3">
            <div class="card stat-card border-0 shadow-sm h-100 position-relative overflow-hidden">
                <div class="card-body p-4">
                    <div class="stat-icon-wrapper d-flex align-items-center justify-content-center bg-light-orange text-first rounded-3 mb-3">
                        <i class="fas fa-person-chalkboard fa-lg"></i>
                    </div>
                    <span class="text-muted small-text uppercase-bold d-block mb-1">Active Staff</span>
                    <h3 class="display-6 fw-bold mb-0 text-dark-title"><?php echo e($employeeCount); ?></h3>
                    <div class="stat-trend mt-2 text-muted small d-flex align-items-center gap-1">
                        <i class="fas fa-circle-check text-success"></i>
                        <span>Fully Managed</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Attendance Stat -->
        <div class="col-12 col-sm-6 col-xl-3">
            <div class="card stat-card border-0 shadow-sm h-100 position-relative overflow-hidden">
                <div class="card-body p-4">
                    <div class="stat-icon-wrapper d-flex align-items-center justify-content-center bg-light-orange text-first rounded-3 mb-3">
                        <i class="fas fa-clipboard-check fa-lg"></i>
                    </div>
                    <span class="text-muted small-text uppercase-bold d-block mb-1">Attendance Today</span>
                    <h3 class="display-6 fw-bold mb-0 text-dark-title"><?php echo e($attendanceCount); ?></h3>
                    <div class="stat-trend mt-2 text-warning small d-flex align-items-center gap-1">
                        <i class="fas fa-clock"></i>
                        <span>Daily Tracking</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Pending Invoices Stat -->
        <div class="col-12 col-sm-6 col-xl-3">
            <div class="card stat-card border-0 shadow-sm h-100 position-relative overflow-hidden">
                <div class="card-body p-4">
                    <div class="stat-icon-wrapper d-flex align-items-center justify-content-center bg-light-orange text-first rounded-3 mb-3">
                        <i class="fas fa-file-invoice-dollar fa-lg"></i>
                    </div>
                    <span class="text-muted small-text uppercase-bold d-block mb-1">Pending Invoices</span>
                    <h3 class="display-6 fw-bold mb-0 text-dark-title"><?php echo e($dueInvoices); ?></h3>
                    <div class="stat-trend mt-2 text-danger small d-flex align-items-center gap-1">
                        <i class="fas fa-circle-exclamation"></i>
                        <span>Requires Attention</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Data Tables Grid -->
    <div class="row g-4">
        <!-- Recent Attendance -->
        <div class="col-12 col-lg-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-transparent border-0 pt-4 px-4 d-flex align-items-center justify-content-between">
                    <h5 class="mb-0 fw-bold d-flex align-items-center gap-2">
                        <i class="fas fa-clock text-first"></i> Recent Attendance
                    </h5>
                    <a href="<?php echo e(route('attendances.index')); ?>" class="btn btn-sm btn-light text-first fw-semibold px-3 py-1.5 rounded-2">View All</a>
                </div>
                <div class="card-body px-4 pb-4">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light-head">
                                <tr>
                                    <th class="ps-0">Student</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th class="text-end pe-0">Fine</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $recentAttendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="fw-semibold ps-0"><?php echo e($attendance->student->first_name); ?> <?php echo e($attendance->student->last_name); ?></td>
                                        <td class="text-muted small"><?php echo e($attendance->attendance_date); ?></td>
                                        <td>
                                            <span class="status-badge status-<?php echo e(strtolower($attendance->status)); ?>">
                                                <?php echo e($attendance->status); ?>

                                            </span>
                                        </td>
                                        <td class="text-end fw-bold pe-0 text-dark-title">
                                            <?php if($attendance->fine > 0): ?>
                                                $<?php echo e(number_format($attendance->fine, 2)); ?>

                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="text-center text-muted py-4">No recent attendance records.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Latest Invoices -->
        <div class="col-12 col-lg-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-transparent border-0 pt-4 px-4 d-flex align-items-center justify-content-between">
                    <h5 class="mb-0 fw-bold d-flex align-items-center gap-2">
                        <i class="fas fa-receipt text-first"></i> Latest Invoices
                    </h5>
                    <a href="<?php echo e(route('fee_invoices.index')); ?>" class="btn btn-sm btn-light text-first fw-semibold px-3 py-1.5 rounded-2">View All</a>
                </div>
                <div class="card-body px-4 pb-4">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light-head">
                                <tr>
                                    <th class="ps-0">Invoice</th>
                                    <th>Student</th>
                                    <th>Status</th>
                                    <th class="text-end pe-0">Due Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $recentInvoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="fw-bold text-first ps-0"><?php echo e($invoice->invoice_no); ?></td>
                                        <td class="fw-semibold"><?php echo e($invoice->student->first_name); ?> <?php echo e($invoice->student->last_name); ?></td>
                                        <td>
                                            <span class="status-badge status-<?php echo e(strtolower($invoice->status)); ?>">
                                                <?php echo e($invoice->status); ?>

                                            </span>
                                        </td>
                                        <td class="text-end fw-bold pe-0 text-dark-title">
                                            $<?php echo e(number_format($invoice->due_amount, 2)); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="text-center text-muted py-4">No recent fee invoices.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp1\htdocs\fees-manager\fees-manager-laravel\resources\views/dashboard.blade.php ENDPATH**/ ?>