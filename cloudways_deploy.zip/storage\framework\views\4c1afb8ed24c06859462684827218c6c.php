

<?php $__env->startSection('title', 'Staff'); ?>

<?php $__env->startSection('page-title', 'Staff Management'); ?>

<?php $__env->startSection('content'); ?>
    <div class="toolbar">
        <form class="filter-form" method="GET" action="<?php echo e(route('employees.index')); ?>">
            <input type="text" name="search" placeholder="Search staff" value="<?php echo e(request('search')); ?>" />
            <button type="submit" class="button button-secondary">Filter</button>
        </form>
        <a href="<?php echo e(route('employees.create')); ?>" class="button button-primary">Add Staff</a>
    </div>

    <div class="card table-card">
        <table class="table">
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Name</th>
                    <th>Department</th>
                    <th>Designation</th>
                    <th>Phone</th>
                    <th>Salary</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($employee->employee_code); ?></td>
                        <td><?php echo e($employee->user?->name ?? 'No login'); ?></td>
                        <td><?php echo e($employee->department); ?></td>
                        <td><?php echo e($employee->designation); ?></td>
                        <td><?php echo e($employee->phone); ?></td>
                        <td><?php echo e(number_format($employee->salary, 2)); ?></td>
                        <td><?php echo e($employee->status ? 'Active' : 'Inactive'); ?></td>
                        <td class="action-cell">
                            <a href="<?php echo e(route('employees.edit', $employee)); ?>" class="button button-secondary small">Edit</a>
                            <form action="<?php echo e(route('employees.destroy', $employee)); ?>" method="POST" class="inline-form" onsubmit="return confirm('Delete staff record?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="button button-danger small">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="8">No staff records found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="pagination-wrapper"><?php echo e($employees->links()); ?></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp1\htdocs\fees-manager\fees-manager-laravel\resources\views/employees/index.blade.php ENDPATH**/ ?>