

<?php $__env->startSection('title', 'Fee Invoices'); ?>

<?php $__env->startSection('page-title', 'Fee Invoice Management'); ?>

<?php $__env->startSection('content'); ?>
    <div class="toolbar">
        <form class="filter-form" method="GET" action="<?php echo e(route('fee_invoices.index')); ?>">
            <input type="text" name="search" placeholder="Invoice or student" value="<?php echo e(request('search')); ?>" />
            <select name="status">
                <option value="">All status</option>
                <option value="Paid" <?php echo e(request('status') === 'Paid' ? 'selected' : ''); ?>>Paid</option>
                <option value="Partial" <?php echo e(request('status') === 'Partial' ? 'selected' : ''); ?>>Partial</option>
                <option value="Unpaid" <?php echo e(request('status') === 'Unpaid' ? 'selected' : ''); ?>>Unpaid</option>
            </select>
            <button type="submit" class="button button-secondary">Filter</button>
        </form>
        <a href="<?php echo e(route('fee_invoices.create')); ?>" class="button button-primary">Create Invoice</a>
    </div>

    <div class="card table-card">
        <table class="table">
            <thead>
                <tr>
                    <th>Invoice No</th>
                    <th>Student</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Due</th>
                    <th>Payment Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($invoice->invoice_no); ?></td>
                        <td><?php echo e($invoice->student->first_name); ?> <?php echo e($invoice->student->last_name); ?></td>
                        <td><?php echo e(number_format($invoice->total_amount, 2)); ?></td>
                        <td><?php echo e($invoice->status); ?></td>
                        <td><?php echo e(number_format($invoice->due_amount, 2)); ?></td>
                        <td><?php echo e($invoice->payment_date); ?></td>
                        <td class="action-cell">
                            <form action="<?php echo e(route('fee_invoices.destroy', $invoice)); ?>" method="POST" class="inline-form" onsubmit="return confirm('Delete invoice?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="button button-danger small">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="7">No fee invoices found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="pagination-wrapper"><?php echo e($invoices->links()); ?></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp1\htdocs\fees-manager\fees-manager-laravel\resources\views/fee_invoices/index.blade.php ENDPATH**/ ?>