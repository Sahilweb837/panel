

<?php $__env->startSection('title', 'Expenses'); ?>

<?php $__env->startSection('page-title', 'Office Expenses'); ?>

<?php $__env->startSection('content'); ?>
    <div class="toolbar">
        <form class="filter-form" method="GET" action="<?php echo e(route('expenses.index')); ?>">
            <input type="text" name="search" placeholder="Category or description" value="<?php echo e(request('search')); ?>" />
            <input type="date" name="date" value="<?php echo e(request('date')); ?>" />
            <button type="submit" class="button button-secondary">Filter</button>
        </form>
        <a href="<?php echo e(route('expenses.create')); ?>" class="button button-primary">Add Expense</a>
    </div>

    <div class="card table-card">
        <table class="table">
            <thead>
                <tr>
                    <th>Category</th>
                    <th>Amount</th>
                    <th>Date</th>
                    <th>Description</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($expense->category); ?></td>
                        <td><?php echo e(number_format($expense->amount, 2)); ?></td>
                        <td><?php echo e($expense->expense_date); ?></td>
                        <td><?php echo e($expense->description); ?></td>
                        <td class="action-cell">
                            <form action="<?php echo e(route('expenses.destroy', $expense)); ?>" method="POST" class="inline-form" onsubmit="return confirm('Delete expense?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="button button-danger small">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5">No expenses recorded.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="pagination-wrapper"><?php echo e($expenses->links()); ?></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp1\htdocs\fees-manager\fees-manager-laravel\resources\views/expenses/index.blade.php ENDPATH**/ ?>